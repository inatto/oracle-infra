prompt --install_page
@@application/set_environment.sql
@@application/pages/delete_00026.sql
@@application/pages/page_00026.sql
@@application/end_environment.sql
