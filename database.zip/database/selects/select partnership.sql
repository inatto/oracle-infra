select * from partnership;

