select *
from ticket
    ;