select * from tenant;

