
SELECT *
FROM convenio
;


